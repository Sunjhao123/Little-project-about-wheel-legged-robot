//
// Created by qiayuan on 2021/11/15.
//

#include "legged_estimation/StateEstimateBase.h"

#include <ocs2_centroidal_model/FactoryFunctions.h>
#include <ocs2_legged_robot/common/Types.h>
#include <ocs2_robotic_tools/common/RotationDerivativesTransforms.h>


#include <ros/ros.h>
#include <gazebo_msgs/ModelStates.h>
#include <nav_msgs/Odometry.h>
#include <tf/transform_broadcaster.h>

namespace legged {
using namespace legged_robot;
nav_msgs::Odometry odom1;
ros::Subscriber model_state_sub;
static tf::TransformBroadcaster odom_broadcaster;
geometry_msgs::TransformStamped odom_trans;
void modelStateCallback(const gazebo_msgs::ModelStates::ConstPtr& msg);

StateEstimateBase::StateEstimateBase(PinocchioInterface pinocchioInterface, CentroidalModelInfo info,
                                     const PinocchioEndEffectorKinematics& eeKinematics)
    : pinocchioInterface_(std::move(pinocchioInterface)),
      info_(std::move(info)),
      eeKinematics_(eeKinematics.clone()),
      rbdState_(vector_t ::Zero(2 * info_.generalizedCoordinatesNum)) {
  ros::NodeHandle nh;
  model_state_sub = nh.subscribe("/gazebo/model_states", 200, modelStateCallback);
  odomPub_.reset(new realtime_tools::RealtimePublisher<nav_msgs::Odometry>(nh, "odom", 10));

  posePub_.reset(new realtime_tools::RealtimePublisher<geometry_msgs::PoseWithCovarianceStamped>(nh, "pose", 10));
}

void modelStateCallback(const gazebo_msgs::ModelStates::ConstPtr& msg)
{
    static ros::Time previous_time = ros::Time::now();
    ros::Time current_time = ros::Time::now();

    // 找到机器人模型（假设模型名为"robot"）
    int robot_index = -1;
    for (size_t i = 0; i < msg->name.size(); ++i)
    {
        if (msg->name[i] == "b2w")  // 替换为您的机器人模型名称
        {
            robot_index = i;
            break;
        }
    }

    if (robot_index == -1)
    {
        ROS_WARN("Robot model not found in Gazebo model states!");
        return;
    }

    // 获取机器人的位置和姿态
    geometry_msgs::Pose robot_pose = msg->pose[robot_index];
    geometry_msgs::Twist robot_twist = msg->twist[robot_index];

    // 设置位置和姿态
    odom1.pose.pose = robot_pose;

    //ROS_INFO("move to x : %f", odom1.pose.pose.position.x);

    // 计算速度（单位：m/s 和 rad/s）
    odom1.twist.twist = robot_twist;

     // 发布TF变换（可选）
    
    /*odom_trans.header.stamp = current_time;
    odom_trans.header.frame_id = "odom";
    odom_trans.child_frame_id = "base";
    odom_trans.transform.translation.x = robot_pose.position.x;
    odom_trans.transform.translation.y = robot_pose.position.y;
    odom_trans.transform.translation.z = robot_pose.position.z;
    odom_trans.transform.rotation = robot_pose.orientation;*/

    
}

void StateEstimateBase::updateJointStates(const vector_t& jointPos, const vector_t& jointVel) {
  rbdState_.segment(6, info_.actuatedDofNum) = jointPos;
  rbdState_.segment(6 + info_.generalizedCoordinatesNum, info_.actuatedDofNum) = jointVel;
}

void StateEstimateBase::updateImu(const Eigen::Quaternion<scalar_t>& quat, const vector3_t& angularVelLocal,
                                  const vector3_t& linearAccelLocal, const matrix3_t& orientationCovariance,
                                  const matrix3_t& angularVelCovariance, const matrix3_t& linearAccelCovariance) {
  quat_ = quat;
  angularVelLocal_ = angularVelLocal;
  linearAccelLocal_ = linearAccelLocal;
  orientationCovariance_ = orientationCovariance;
  angularVelCovariance_ = angularVelCovariance;
  linearAccelCovariance_ = linearAccelCovariance;

  vector3_t zyx = quatToZyx(quat) - zyxOffset_;
  vector3_t angularVelGlobal = getGlobalAngularVelocityFromEulerAnglesZyxDerivatives<scalar_t>(
      zyx, getEulerAnglesZyxDerivativesFromLocalAngularVelocity<scalar_t>(quatToZyx(quat), angularVelLocal));
  updateAngular(zyx, angularVelGlobal);
}

void StateEstimateBase::updateAngular(const vector3_t& zyx, const vector_t& angularVel) {
  rbdState_.segment<3>(0) = zyx;
  rbdState_.segment<3>(info_.generalizedCoordinatesNum) = angularVel;
}

void StateEstimateBase::updateLinear(const vector_t& pos, const vector_t& linearVel) {
  rbdState_.segment<3>(3) = pos;
  rbdState_.segment<3>(info_.generalizedCoordinatesNum + 3) = linearVel;
}




void StateEstimateBase::publishMsgs(const nav_msgs::Odometry& odom) {
  ros::Time time = odom.header.stamp;
  scalar_t publishRate = 200;
  if (lastPub_ + ros::Duration(1. / publishRate) < time) {
    lastPub_ = time;
    if (odomPub_->trylock()) {
      odom1.header.stamp = time;
      odom1.header.frame_id = "odom";
      odom1.child_frame_id = "base";
      // ROS_INFO("s");
      //odom.pose.pose.position.x = odom1.pose.pose.position.x;
      //odom.pose.pose.position.y = odom1.pose.pose.position.y;
      //odom.pose.pose.position.z = odom1.pose.pose.position.z ;
      odomPub_->msg_ = odom1;
      odomPub_->unlockAndPublish();
    }
    if (posePub_->trylock()) {
      posePub_->msg_.header = odom1.header;
      posePub_->msg_.pose = odom1.pose;
      posePub_->unlockAndPublish();
    }
  }
  // odom_broadcaster.sendTransform(odom_trans);
}

}  // namespace legged
