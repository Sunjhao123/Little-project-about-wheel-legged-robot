//
// Created by skywoodsz on 2023/2/28.
//
// copy from: https://github.com/qiayuanliao/legged_control

#ifndef SRC_FROMTOPICEESTIMATE_H
#define SRC_FROMTOPICEESTIMATE_H

#include "legged_estimation/StateEstimateBase.h"

#include <realtime_tools/realtime_buffer.h>

namespace legged{
using namespace ocs2;
using namespace legged_robot;

class FromTopicStateEstimate : public StateEstimateBase {
public:
    FromTopicStateEstimate(PinocchioInterface pinocchioInterface, CentroidalModelInfo info,
                           const PinocchioEndEffectorKinematics& eeKinematics);

    void updateImu(const Eigen::Quaternion<scalar_t>& quat, const vector3_t& angularVelLocal, const vector3_t& linearAccelLocal,
                            const matrix3_t& orientationCovariance, const matrix3_t& angularVelCovariance,
                            const matrix3_t& linearAccelCovariance) override{};
    vector_t update(const ros::Time& time, const ros::Duration& period) override;

private:
    void callback(const nav_msgs::Odometry::ConstPtr& msg);

    ros::Subscriber sub_;
    realtime_tools::RealtimeBuffer<nav_msgs::Odometry> buffer_;
};

}


#endif //SRC_FROMTOPICEESTIMATE_H
